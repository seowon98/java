
public class Mul extends Calc {

	void setValue(int x, int y) {
		a=x;
		b=y;
	}
	int calculate(){
		return a*b;
	}
}

