package pkg2;

import pkg1.Cal;

public class Div extends Cal {

	public void setValue(int x, int y) {
		a=x;
		b=y;
	}
	public int calculate(){
		return a/b;
	}
}
