import java.util.Scanner;

public class Calc {
		int a,b;
		
		void setValue(int x, int y) {
		}
		
		int calculate(int a, int b) {
			return a+b;
		} 
		
		public static void main(String[] args) {

		int result=0;
			
		System.out.print("�� ������ �����ڸ� �Է��Ͻÿ� >> ");
		Scanner scanner = new Scanner(System.in);
		
		int a = scanner.nextInt();
		String cal = scanner.next();
		int b = scanner.nextInt();
		
		Add ad = new Add();
		Sub su = new Sub();
		Mul mu = new Mul();
		Div di = new Div();
		
        if(cal.equals("+")) {
        	ad.setValue(a, b);
        	result=ad.calculate();
        }
        if(cal.equals("-")) {
        	su.setValue(a, b);
        	result=su.calculate();
        }
        if(cal.equals("*")) {
        	mu.setValue(a, b);
        	result=mu.calculate();
        }
       if(cal.equals("/")) {
        	di.setValue(a, b);
        	result=di.calculate();
        }

		System.out.print(result);
			
		
	}

}

